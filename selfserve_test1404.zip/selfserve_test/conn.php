<?php
$servername = "localhost";
$username = "publishe_selfservetest";
$password = "hcselfserve23";
$dbname = "publishe_selfserve_test"; 
$connectDB = mysqli_connect($servername,$username,$password,$dbname);
if (!$connectDB){
    die("Sorry we failed to connect: ". mysqli_connect_error());
}
// else{
//     echo "success";
// }
?>