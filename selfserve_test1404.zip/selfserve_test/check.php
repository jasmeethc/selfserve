<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Upload Assets</title>
</head>
    <script src="https://dynamique.hockeycurve.com/js/hc.min.js"> </script>
    <script src="testp.js"> </script>
    <body>
        <script>
            let assetManager = HC.AssetManager(document.body);
        </script>
    </body>
</html>    