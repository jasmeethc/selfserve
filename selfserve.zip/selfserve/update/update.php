<?php
ob_start();
session_start();
$_SESSION['client_name'];
    if(!$_SESSION['email']){
      header("location: ../login.php");
    }
error_reporting(E_ERROR | E_PARSE);
include "../conn.php";
$id=$_GET['id'];
if(isset($_POST['id'])) {
    $id=$_GET['id'];
}
$_SESSION['id']=$id;
?>
<!DOCTYPE html>
<html lang="en">
<head>
<title>Update</title>
<style>
    
table {
 
  /*border-collapse: collapse;*/
  margin-top:20px;
  /*width: 80%;*/
  font-size:20px;
  
}

td, th {
  border: 1px solid #dddddd;
  padding: 25px 50px 25px 50px !important;

}

</style>
    
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/gsap/1.19.1/TweenMax.min.js"></script>
      <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.4/css/bootstrap.min.css">
      <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.js"></script>
  <script type="text/javascript" src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.4/js/bootstrap.min.js"></script>
   <link rel="stylesheet" href="../style.css" />
</head>

<body>
    
   <ul class="list-unstyled multi-steps">
    <li style="cursor:pointer;" id="updt_creat">Update Creative</li>
    <li style="cursor:pointer;" id="cam_inf">Campaign information</li>
    <li style="cursor:pointer;" id="temp">select template</li>
    <li style="cursor:pointer;" id="upld_ast">Upload assets</li>
    <li class="is-active">Update animation</li>
    <?php 
        $sql2="SELECT * FROM `campaign_info` WHERE id='$id'";
        $data2=mysqli_query($connectDB,$sql2);
        if(mysqli_num_rows($data2)>0){
    while($row2=mysqli_fetch_assoc($data2)){
        $adtag_type=$row2['adtag_type'];
            if($adtag_type!="dcm"){
                ?>
                <li>Add Tracker</li>
                <?php
            }
    }}
    ?>
    
    <li>Click Test</li>
    <li>Previews/Adtags</li>
  </ul>
    <button style="margin-left:20px;" onclick="window.location.href = '../';"><b>Home</b></button>
    <button onclick="window.location.href = '../uploadasset/creative.php?id=<?php echo $id ?>';">Go Back</button>
    <h1 style="margin-left:20px;">Update Animations</h1>
<table style="margin-left:20px;">
 <thead>
    
    <th style="text-align:center">Previews</th>
    <th style="text-align:center">Dimension</th>
    <th style="text-align:center">Update Animation</th>
 </thead>
<?php 
$sql1="SELECT * FROM `campaign_info` WHERE id='$id'";
$data1=mysqli_query($connectDB,$sql1);

if(mysqli_num_rows($data1)>0){
    while($row1=mysqli_fetch_assoc($data1)){
        
    $camp = $row1['campaign_name'];
    $client =  $row1['client_name'];   
    $template = $row1['template'];
    $dimension = $row1['dimension']; 
    $adtag_type=$row1['adtag_type']; 
    $content2 = [];
    $abc=explode(",",$dimension);
    
     for($f=0; $f<count($abc); $f++){
      $abc2=explode("x",$abc[$f]);
         $sql2="SELECT * FROM `creativecode` WHERE name='$template' AND campaign='$camp' AND client='$client' AND dimension='$abc[$f]'";
         $data2=mysqli_query($connectDB,$sql2);
         if(mysqli_num_rows($data2)>0){
             while($rowa=mysqli_fetch_assoc($data2)){
                 $id2=$rowa['id'];
                 $fcat2=$rowa['filter'];
                 $client2=$rowa['client'];
                 array_push($content2,$rowa['content']);
                 ?><script> console.log(" <?php echo $rowa['client'] ?>"); console.log(" <?php echo $rowa['filter'] ?>"); </script> <?php 
 ?>     
 <tr>
     <?php if($rowa['finalcode']==""){
     $code=$rowa['content'];
     }else{
      $code=$rowa['finalcode'];} ?>
 <td style="padding:20px;"><div id="main"  style="position:relative;display:flex;flex-wrap:wrap;width:<?php echo $abc2[0] ?>px; height:<?php echo $abc2[1] ?>px"><?php echo $code ?></div></td>
 <td style="text-align:center;"> <?php echo $rowa['dimension']; ?> </td>
 <td style="text-align:center;"><a href="./testanim.php?id=<?php echo $id2 ?>">Update Animation</a></td></tr>
  <?php              
             }
     }
}


}}
 ?>
  <tr>
    
  </tr>


 
</table>

    <?php
        if($adtag_type=="dcm"){
            ?>
            <form method="POST">
                <button type="submit" class="btn btn-success" name="create" style="position:absolute;top:5px;right:80px">Create ad</button>
            </form>
            <?php 
        }
        else{
            ?>
                <a href="../trackers.php?id=<?php echo $id; ?>" class="btn btn-success" style="position:absolute;top:5px;right:80px">Add trackers</a>
            <?php
        }
    ?>
    
    <a href="../logout.php" class="btn btn-danger" style="position:absolute;top:5px;right:5px">Logout</a>


 </body>
 <script>
     document.getElementById("updt_creat").addEventListener("click",()=>{
        window.location = "../update_creative.php";
    })
     document.getElementById("cam_inf").addEventListener("click",()=>{
        window.location = "../index.php";
    })
    document.getElementById("temp").addEventListener("click",()=>{
        window.location = "../template/index.php?id=<?php echo $id; ?>";
    })
    document.getElementById("upld_ast").addEventListener("click",()=>{
        window.location = "../uploadasset/creative.php?id=<?php echo $id; ?>";
    })
 </script>
</html>

<?php
    $data_arr = array();
    $sql = "SELECT * FROM `campaign_info` WHERE id=$id LIMIT 1";
      $result = mysqli_query($connectDB, $sql);
      $row = mysqli_fetch_assoc($result);
      $camp = $row['campaign_name'];
      $dims = $row['dimension'];

      $str_arr = explode(",", $dims);
if(isset($_POST['create'])){
    
for($ij=0;$ij<count($str_arr);$ij++){
    
    for ($p = 0; $p < count($str_arr); $p++){
        
        if ($row["lp_type"] == "imp") {
        $impressions = $_POST['impp'.$p];
        $clicks = $_POST['clik'.$p];
        $sql3 = "UPDATE creativecode SET clicks = '$clicks'  WHERE `campaign` = '$camp' AND `dimension` = '$str_arr[$p]'";
        $executeQuery = mysqli_query($connectDB, $sql3);
        $sql4 = "UPDATE creativecode SET impressions = '$impressions'  WHERE `campaign` = '$camp' AND `dimension` = '$str_arr[$p]'";
        $executeQuery2 = mysqli_query($connectDB, $sql4);
        header("location:trackers.php?id=" . $id);
        } else if ($row["lp_type"] == "utm" || $row["lp_type"] == "lp") {
            $clicks = $_POST['land'.$p];
            $sql7 = "UPDATE creativecode SET clicks = '$clicks'  WHERE `campaign` = '$camp' AND `dimension` = '$str_arr[$p]'";
        $executeQuery3 = mysqli_query($connectDB, $sql7);
        header("location:trackers.php?id=" . $id);

        }
        
    };
    
    $url = 'https://dynamique.hockeycurve.com/publish-creativedata?key=Kth7NS3ACWX2';
    $sql_arr = "SELECT * FROM `creativecode` WHERE `campaign` = '$camp' AND `dimension` = '$str_arr[$ij]'";
        $result_arr = mysqli_query($connectDB, $sql_arr);
        $row_arr = mysqli_fetch_assoc($result_arr);
        $client_dt = $row_arr['client'];
        $fcat_dt = $row_arr['filter'];
        $dim_dt = $row_arr['dimension'];
        if($row_arr['clicks']!=""&&$row_arr['impressions']!=""){
            $impressiontracker='<script>
imp1="'.$row_arr["impressions"].'".split("[timestamp]")[0]
imp2="'.$row_arr["impressions"].'".split("[timestamp]")[1]

var time = (new Date())/1000
    var frame = document.getElementById("imptag");
    function trigIframe(){
        var frame = document.createElement("iframe")
        frame.style["display"] = "none"
        frame.src = imp1+time+imp2
        document.body.appendChild(frame)
    }
    setTimeout(trigIframe, 5000)
    </script>
';
            $clicktracker='<script>

document.getElementById("clickurl").href = "'.$row_arr['clicks'].'";var elem = document.getElementsByTagName("a")[0];if(json["click_macro"]){elem.href = elem.href;var target = json["click_macro"];var url = elem.href;elem.href = "https://ad.hockeycurve.com/clk.php?redirect="+url+"&tracking="+encodeURIComponent(target)+"&stats="+encodeURIComponent(json[`stats`])+"&token_id="+encodeURIComponent(json[`token_id`])}
</script>';
        $content_dt = $row_arr['finalcode'].$impressiontracker.$clicktracker;
        }
        else if($row_arr['clicks']!=""){
            $clicktracker='<script>

document.getElementById("clickurl").href = "'.$row_arr['clicks'].'";var elem = document.getElementsByTagName("a")[0];if(json["click_macro"]){elem.href = elem.href;var target = json["click_macro"];var url = elem.href;elem.href = "https://ad.hockeycurve.com/clk.php?redirect="+url+"&tracking="+encodeURIComponent(target)+"&stats="+encodeURIComponent(json[`stats`])+"&token_id="+encodeURIComponent(json[`token_id`])}
</script>';
        $content_dt = $row_arr['finalcode'].$clicktracker;
        }
        else{
            $clicktracker='<script>
                var landing_page = "https://www.primevideo.com/";if(window.location.href.indexOf("lp0")!=-1){landing_page = window.location.href.split("lp0=")[1].split("&")[0];}
    
    var elem = document.getElementsByTagName("a")[0];
    if(json[`click_macro`]){
        elem.href = elem.href
        var target = json[`click_macro`];
        var url = landing_page;
        elem.href = "https://ad.hockeycurve.com/clk.php?redirect="+encodeURIComponent(url)+"&tracking="+encodeURIComponent(target)+"&stats="+encodeURIComponent(json[`stats`])+"&token_id="+encodeURIComponent(json[`token_id`]);}
            </script>';
            $content_dt = $row_arr['finalcode'].$clicktracker;
        }
        
        $data_arr[$dim_dt] = $content_dt;
    }
        
    $postData = array(
        'client' => $client_dt,
        'category' => $fcat_dt,
        'concept' => 'popular',
        'data' => $data_arr
    );
    
    $abc = json_encode($postData);
    // Setup cURL
    $ch = curl_init($url);
    curl_setopt_array($ch, array(
        CURLOPT_POST => TRUE,
        CURLOPT_RETURNTRANSFER => TRUE,
        CURLOPT_HTTPHEADER => array(
            'Content-Type: application/json'
        ),
        CURLOPT_POSTFIELDS => $abc
    ));

// Send the request
$response = curl_exec($ch);
header("location:../clicktest.php?id=" . $id);
}
?>