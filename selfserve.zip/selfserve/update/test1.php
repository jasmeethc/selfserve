<?php
ob_start();
session_start();
    if(!$_SESSION['email']){
      header("location: ../login.php");
    }
error_reporting(E_ERROR | E_PARSE);
include ".../conn.php";
$id=$_GET['id'];
if(isset($_POST['id'])) {
    $id=$_GET['id'];
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
<title>Update</title>
<style>
    
table {
 
  border-collapse: collapse;
  margin-top:20px;
  width: 80%;
  font-size:20px;
  
}

td, th {
  border: 1px solid #dddddd;
  padding: 25px 50px 50px 50px;

}

</style>
     <link rel="stylesheet" href=".../style.css" />
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/gsap/1.19.1/TweenMax.min.js"></script>
      <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.4/css/bootstrap.min.css">
      <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.js"></script>
  <script type="text/javascript" src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.4/js/bootstrap.min.js"></script>
</head>

<body>
   <ul class="list-unstyled multi-steps">
    <li>Registration form</li>
    <li>Login</li>
    <li style="cursor:pointer;" id="cam_inf">Campaign information</li>
    <li style="cursor:pointer;" id="temp">select template</li>
    <li style="cursor:pointer;" id="upld_ast">Upload assets</li>
    <li class="is-active">Update animation</li>
    <li>Add Tracker</li>
    <li>Previews/Adtags</li>
  </ul>
    <button style="margin-left:20px;" onclick="window.location.href = '../';"><b>Home</b></button>
    <button onclick="window.location.href = '../uploadasset/creative.php?id=<?php echo $id ?>';">Go Back</button>
    <h1 style="margin-left:20px;">Update Animations</h1>
<table style="margin-left:20px;">
 <thead>
    
    <th>Previews</th>
    <th>Dimension</th>
    <th>Update Animation</th>
 </thead>
<?php 
$sql1="SELECT * FROM `campaign_info` WHERE id='$id'";
$data1=mysqli_query($connectDB,$sql1);

if(mysqli_num_rows($data1)>0){
    while($row1=mysqli_fetch_assoc($data1)){
        
    $camp = $row1['campaign_name'];
    $client =  $row1['client_name'];   
    $template = $row1['template'];
    $dimension = $row1['dimension']; 
    $content2 = [];
    $abc=explode(",",$dimension);
    
     for($f=0; $f<count($abc); $f++){
      $abc2=explode("x",$abc[$f]);
         $sql2="SELECT * FROM `creativecode` WHERE name='$template' AND campaign='$camp' AND client='$client' AND dimension='$abc[$f]'";
         $data2=mysqli_query($connectDB,$sql2);
         if(mysqli_num_rows($data2)>0){
             while($rowa=mysqli_fetch_assoc($data2)){
                 $id2=$rowa['id'];
                 $fcat2=$rowa['filter'];
                 $client2=$rowa['client'];
                 array_push($content2,$rowa['content']);
                 ?><script> console.log(" <?php echo $rowa['client'] ?>"); console.log(" <?php echo $rowa['filter'] ?>"); </script> <?php 
 ?>     
 <tr>
     <?php if($rowa['finalcode']==""){
     $code=$rowa['content'];
     }else{
      $code=$rowa['finalcode'];} ?>
 <td><div id="main"  style="position:relative;display:flex;flex-wrap:wrap;width:<?php echo $abc2[0] ?>px; height:<?php echo $abc2[1] ?>px"><?php echo $code ?></div></td>
 <td style="text-align:center;"> <?php echo $rowa['dimension']; ?> </td>
 <td style="text-align:center;"><a href="./testanim.php?id=<?php echo $id2 ?>">Update Animation</a></td></tr>
  <?php              
             }
     }
}


}}
 ?>
  <tr>
    
  </tr>


 
</table>
<form method="post">
    <a href="../trackers.php?id=<?php echo $id; ?>" class="btn btn-success" style="position:absolute;top:5px;right:80px">Add trackers</a>
    <a href="../logout.php" class="btn btn-danger" style="position:absolute;top:5px;right:5px">Logout</a>
</form>

 </body>
 <script>
     
     document.getElementById("cam_inf").addEventListener("click",()=>{
        window.location = "../index.php";
    })
    document.getElementById("temp").addEventListener("click",()=>{
        window.location = "../template/index.php?id=<?php echo $id; ?>";
    })
    document.getElementById("upld_ast").addEventListener("click",()=>{
        window.location = "../uploadasset/creative.php?id=<?php echo $id; ?>";
    })
 </script>
</html>
