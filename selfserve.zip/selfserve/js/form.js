
       function myFunction(id) 
        {
            
            var namee = document.getElementById(id).name;
            // alert(namee);
            var a = document.getElementById(id).value
                if(namee == 'title')
                {
                    var b = parseInt(a.length);
                    var count = 1000-b;
                    document.getElementById(namee).innerHTML="Character left " + count;

                }
                if(namee == 'descp')
                {
                    var b = parseInt(a.length);
                    var count = 1000-b;
                    document.getElementById(namee).innerHTML="Character left " + count;

                }
                if(namee == 'content')
                {
                    var b = parseInt(a.length);
                    var count = 2000-b;
                    document.getElementById(namee).innerHTML="Character left " + count;

                }
                if(namee == 'key' )
                {
                    var b = parseInt(a.length);
                    var count = 2000-b;
                    document.getElementById(namee).innerHTML="Character left " + count;

                }
                if(namee == 'catg')
                {
                    var b = parseInt(a.length);
                    var count = 2000-b;
                    document.getElementById(namee).innerHTML="Character left " + count;

                }
                if(namee == 'author')
                {
                    var b = parseInt(a.length);
                    var count = 2000-b;
                    document.getElementById(namee).innerHTML="Character left " + count;

                }
                if(namee == 'read')
                {
                    
                    var b = parseInt(a.length);
                    var count = 2000-b;
                    document.getElementById(namee).innerHTML="Character left " + count;

                }
                if(namee == 'currentscenario')
                {
                   
                    var b = parseInt(a.length);
                    var count = 2000-b;
                    document.getElementById(namee).innerHTML="Character left " + count;

                }
                if(namee == 'challenge')
                {
                    var b = parseInt(a.length);
                    var count = 2000-b;
                    document.getElementById(namee).innerHTML="Character left " + count;

                }
                if(namee == 'whywhatchange')
                {
                    var b = parseInt(a.length);
                    var count = 2000-b;
                    document.getElementById(namee).innerHTML="Character left " + count;

                }
                if(namee == 'chang')
                {
                    var b = parseInt(a.length);
                    var count = 2000-b;
                    document.getElementById(namee).innerHTML="Character left " + count;

                }
                if(namee == 'changreason')
                {
                    var b = parseInt(a.length);
                    var count = 2000-b;
                    document.getElementById(namee).innerHTML="Character left " + count;

                }
                if(namee == 'solution')
                {
                    var b = parseInt(a.length);
                    var count = 2000-b;
                    document.getElementById(namee).innerHTML="Character left " + count;

                }
        }     

     