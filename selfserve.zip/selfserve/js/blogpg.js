
    function submitt(id)
    {
        window.location.href = " "+"?id="+id;
        // alert("helo");
        

    }
    
