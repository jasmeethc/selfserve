<?php
include "conn.php";
error_reporting(E_ERROR | E_PARSE);
session_start();
$client_names = $_SESSION['client_nm'];
if(isset($_POST["submit"])){
        $camp_name = $_POST['camp_nm'];
        $sql = "SELECT * FROM `campaign_info` WHERE campaign_title='$camp_name'";
    $result = mysqli_query($connectDB,$sql);
    if(mysqli_num_rows($result)>0){
        while($row=mysqli_fetch_assoc($result)){
             $_SESSION['id'] = $row['id'];
            $dimension = $row['dimension']; 
            $camp =  $row['campaign_name'];
            $client =  $row['client_name'];
            $ep_dim = explode(",",$dimension);
            $single_dim = $ep_dim[0];
            $_SESSION['creative_type'] = "update";

            $sql_creatcode = "SELECT * FROM `creativecode` WHERE client='$client' AND campaign='$camp' AND dimension='$single_dim'";
            $result_creatcode = mysqli_query($connectDB,$sql_creatcode);
            if(mysqli_num_rows($result_creatcode)>0){
                while($row_creatcode=mysqli_fetch_assoc($result_creatcode)){
                    $_SESSION['fcat'] = $row_creatcode['filter'];
                }
            }
        }
        header("location: index.php");
    }
}

if(isset($_POST["new_creative"])){
    $autofcats = "";
    $characters = 'abcdefghijklmnopqrstuvwxyz0123456789';
  $charCount = strlen($characters);
  for($i=0;$i<6;$i++){
    $autofcats.= substr($characters,rand(0,$charCount),1);
  }
    $_SESSION['fcat'] = $autofcats;
    $_SESSION['id'] = '';
    $_SESSION['creative_type'] = '';
    header("location: index.php");
}
?>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.1/jquery.js"></script>
    <title>Update creative</title>
    <link rel="stylesheet" href="style.css" />
</head>
<body>
    <style>
        .container{
            width: 100%;
            height:70vh;
            display:flex;
            flex-direction:column;
            justify-content: center;
            align-items:center;
        }
        .cnt_btn{
            width: 100%;
            height:100%;
            display:flex;
            flex-direction:column;
            justify-content: center;
            align-items:center;
        }
        button{
            width: 200px;
            height:60px;
            margin: 10px 0 20px;
            font-size: 1rem;
            cursor: pointer;
        }
        select{
            width: 300px;
            height: 40px;
            font-size: 1.2rem;
        }
    </style>
    <div class="main">
          <ul class="list-unstyled multi-steps">
            <li class="is-active">Update Creative</li>
            <li>Campaign information</li>
            <li>select template</li>
            <li>Upload assets</li>
            <li>Update animation</li>
            <?php 
        $sql2="SELECT * FROM `campaign_info` WHERE id='$id'";
        $data2=mysqli_query($connectDB,$sql2);
        if(mysqli_num_rows($data2)>0){
    while($row2=mysqli_fetch_assoc($data2)){
        $adtag_type=$row2['adtag_type'];
            if($adtag_type!="dcm"){
                ?>
                <li>Add Tracker</li>
                <?php
            }
    }}
    ?>
            <li>Click Test</li>
            <li>Previews/Adtags</li>
          </ul>
    <h1 style="text-align:center;position:absolute;top:140px;left:50%;transform:translateX(-50%);">Create new creative/Update creative</h1>
    <a href="logout.php" style="position:absolute;top:5px;right:5px;color: #fff;background-color: #d9534f;border-color: #d43f3a;text-decoration: none;padding: 10px;border-radius: 5px">Logout</a>
    <div class="container">
        <div class="cnt_btn" id="cnt_btn">
            <form method="post">
                <button name="new_creative">Create new creative</button>
            </form>
            <button id="update_creat">Update existing creative</button>
        </div>
    </div>
   <script>
        $(document).ready(function(){
            $("#update_creat").on("click",function(e){
                e.preventDefault();
                $.ajax({
              url : "get_creative.php",
              type : "POST",
              dataType : "JSON",
              data:{
                  client: '<?php echo $client_names ?>',
              },
              success : function(data){
                  console.log(data)
                  $("#cnt_btn").html(data.content)
              }
           })
            })
        })
   </script>
</body>
</html>
