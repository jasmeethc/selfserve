


    <!--// var client = "clienttest";-->
    <!--// var folder = "mzindodi22";-->
    <!--// var dim = "320x480";-->
    <!--// var keyss;-->
    

     
    <!--// //  without loop-->
    <!--//   async function postName() -->
    <!--//   {-->
         
    <!--//       const object = { "paths":[client+'/'+folder+'/'+dim+'/']};-->
    <!--//       const response = await fetch('https://dynamique.hockeycurve.com/keys?key=Kth7NS3ACWX2', {-->
    <!--//         method: 'POST',-->
    <!--//         body: JSON.stringify(object)-->
    <!--//       });-->
    <!--//       const test = await response.json();-->
    <!--//       console.log(test); // logs 'OK'-->
    <!--//     //   console.log(typeof(test));-->
          
    <!--//       keyss = test['data'][0]['key'];-->

           
    <!--//     assetManager.showFolders([{path:client+"/"+folder+"/"+dim+"/",key:keyss}])-->
    <!--// }-->
    <!--//  postName();-->


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Upload Assets</title>
</head>
    <script src="https://dynamique.hockeycurve.com/js/hc.min.js"> </script>
<body>
<script>

//   let assetManager = HC.AssetManager(document.body)

console.log("SS")

</script>
</body>
<?php
$url = 'https://dynamique.hockeycurve.com/keys?key=Kth7NS3ACWX2';

        $params = array(
                "paths"=>"clienttest/mzindodi22/300x250/"
            );
echo $url;
print_r($param);
        // Create a new Request object
        $request = new Request($url, 'POST', $params);

        // Send the request
        $request->send();

        // Get the Response object
        $response = $request->getResponse();

        if($response->getStatusCode() == 200) {

            // Retrieve the session token details
            $token = $response->getBodyDecoded();

            print_r($token);
        }
        else {

            echo $response->getStatusCode() . PHP_EOL;
            echo $response->getReasonPhrase() . PHP_EOL;
            echo $response->getBody() . PHP_EOL;
        }

?>


</html>