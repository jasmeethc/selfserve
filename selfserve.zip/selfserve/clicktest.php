<?php
ob_start();
session_start();
if(!$_SESSION['email']){
  header("location: login.php");
}
include "conn.php";
error_reporting(E_ERROR | E_PARSE);
$id = $_GET['id'];
if (isset($_POST['id'])) {
  $id = $_GET['id'];
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <link rel="stylesheet" href="style.css" />
  <title>Click Test</title>
  <style>
    .container {
      margin-left: 100px;
    }

    .popup {
      height: 200px;
      width: 300px;
      position: fixed;
      top: 45%;
      left: 42%;
      color: black;
      font-weight: bold;
      border: 3px solid black;
      background: #b9ebff;
      text-align: center;
      justify-content: center;
    }

    .popup2 {
      height: 270px;
      width: 300px;
      position: fixed;
      top: 45%;
      left: 42%;
      border: 3px solid black;
      z-index: 10;
      background: #b9ebff;
      text-align: center;
      justify-content: center;
    }

    .btn1 {
      position: absolute;
      top: 68%;
      left: 10%;
      background-color: green;
      color: white;
      width: 110px;
      height: 33px
    }

    .btn2 {
      position: absolute;
      top: 68%;
      background-color: red;
      color: white;
      width: 110px;
      height: 33px
    }

    
    .box1 {
      position: absolute;
      top: 120px;
      left: 115px;
      /* border: 2px solid grey; */
      width: 1447px;
      height: 40px;
      display: flex;
      align-items: center;
    }
  </style>
</head>

<body>
  <form method="POST">
    <div>
        <ul class="list-unstyled multi-steps">
    <li style="cursor:pointer;" id="updt_creat">Update Creative</li>
    <li style="cursor:pointer;" id="cam_inf">Campaign information</li>
    <li style="cursor:pointer;" id="temp">select template</li>
    <li style="cursor:pointer;" id="upld_ast">Upload assets</li>
    <li style="cursor:pointer;" id="update_anim">Update animation</li>
    <?php 
        $sql2="SELECT * FROM `campaign_info` WHERE id='$id'";
        $data2=mysqli_query($connectDB,$sql2);
        if(mysqli_num_rows($data2)>0){
    while($row2=mysqli_fetch_assoc($data2)){
        $adtag_type=$row2['adtag_type'];
            if($adtag_type!="dcm"){
                ?>
                <li style="cursor:pointer;" id="add_trk">Add Tracker</li>
                <?php
            }
    }}
    ?>
    <li class="is-active">Click Test</li>
    <li>Previews/Adtags</li>
  </ul>
  <a href="logout.php" class="btn btn-danger" style="position:absolute;top:5px;right:5px">Logout</a>
      <?php
      $sql = "SELECT * FROM `campaign_info` WHERE id=$id LIMIT 1";
      $result = mysqli_query($connectDB, $sql);
      $row = mysqli_fetch_assoc($result);
      $cmp_tl=$row['campaign_title'];
      ?>
      <h2 style="text-align:center"><?php echo $row['campaign_title'] ?></h2>
      <div class="box1">
        <div style="position: absolute;top: 7px;left: 419px;font-size: 17px;font-weight: bold;">This icon indicates "click test is done"</div>
        <div style="position:absolute;top:7px;left:812px;font-size: 17px;font-weight: bold;">This icon indicates "click test is pending"</div>
        <img id="green" style="position: absolute;top: 2px;left:377px;width: 30px;height: 30px;" src="./tick.webp">
        <img id="red" style="position:absolute;top:2px;left:773px;width:30px;height:30px" src="./cross.png">
        <!--<img id="icon" style="    position: absolute;top: 4px;right: 6px;width: 26px;height: 27px;" src="./icon.png">-->
      </div>

      <br><br>
      
      <?php  if($adtag_type!="dcm"){
                ?>
                <button class="btn btn-primary" name="update_trackers" style="position: absolute;top: 100px;left: 115px;">Update Trackers</button>
                <?php
            }?>
      <button name="retest" class="btn btn-primary" style="position: absolute;top: 100px;left: 1507px;">Retest</button>
    </div>
    <br>
    <div class="container" style="width: 1447px;">
      
          <?php
          $dims = $row['dimension'];

          $str_arr = explode(",", $dims);
          $i = 0;
          while ($i < count($str_arr)) {
            $wh_dim = explode("x", $str_arr[$i]) ?>
            <div style="display: flex;">
              <div style="margin: 0px 50px 0px 0px;font-size:18px;"><?php echo $str_arr[$i] ?></div><br>
              <div style="margin: 0px 20px;" id='<?php echo $i ?>'>
                <?php
                $camp=$row['campaign_name'];
                $client=$row['client_name'];
                
                $sql_creatcode = "SELECT * FROM `creativecode` WHERE client='$client' AND campaign='$camp' AND dimension='$str_arr[$i]'";
            $data_creatcode=mysqli_query($connectDB,$sql_creatcode);
      $row1 = mysqli_fetch_assoc($data_creatcode);
                    if ($row["adtag_type"] == "dcm") {
                  ?><div class='hockeycurve-v1'>
                      <iframe id='main-ad-tag<?php echo $i ?>' frameborder='0' scrolling='no' width='<?php echo $wh_dim[0] ?>' height='<?php echo $wh_dim[1] ?>'></iframe>



                      <script type='text/javascript'>
                        var params = {
                          'client': '<?php echo $client ?>',
                          'fcat': '<?php echo $row1['filter'] ?>',
                          'ct0': '%c_esc',
                          'lp0': '%u',
                          'cb': '%n',
                          'dbmc': '<?php echo $row1['filter'] ?>'
                        }
                        var cs = '';
                        for (var p in params) {
                          cs += '&' + encodeURIComponent(p) + '=' + encodeURIComponent(params[p]);
                        }
                        var final_src = 'https://ad.hockeycurve.com/ad.php?zoneid=<?php echo $str_arr[$i] ?>&partner=dcm&hct=master&optout=false' + cs
                        document.getElementById('main-ad-tag<?php echo $i ?>').src = final_src
                      </script><br>
</div>
                    <?php } else if ($row["adtag_type"] == "dv360") { ?>
                      <iframe id='main-ad-tag<?php echo $i ?>' src='https://ad.hockeycurve.com/ad.php?zoneid=<?php echo $str_arr[$i] ?>&client=<?php echo $client ?>&fcat=<?php echo $row1['filter'] ?>&partner=dbm&hct=master&optout=false&ct0=${CLICK_URL_ENC}&cb=${CACHEBUSTER}&dbmc=${CAMPAIGN_ID}' frameborder='0' scrolling='no' width='<?php echo $wh_dim[0] ?>' height='<?php echo $wh_dim[1] ?>'></iframe>
                    <?php }
                ?>
              </div>
  </form>
  <div style="margin: 0px 20px;"><button id='tag<?php echo $i ?>' name='ctest<?php echo $i ?>' style="visibility: hidden;">Check</button></div>
  <div style="margin: 0px 20px;position:absolute;left:1507px;"><?php $clk = $row['click_test'];

            $clk2 = explode(",", $clk);
            $cclk = count($clk2);
            $sclk = array_sum($clk2);

            if ($clk2[$i] == 0) {
      ?><img  height="30px" width="30px" src="./cross.png" alt=""> <?php
                                                                } else {
                                                                  ?><img  height="30px" width="30px" src="./tick.webp" alt=""> <?php
                                                                                                                            }


                                                                                                                              ?></div>
  
                                                                                                                          </div><br><br><br><?php
            $i++;
          }
        ?>



<?php
if (isset($_POST['update_trackers'])) {
header("location:trackers.php?id=" . $id);
}
for ($p = 0; $p < count($str_arr); $p++) {

  if (isset($_POST['ctest' . $p])) {
    $clk2[$p] = 1;
    $clk3 = implode(",", $clk2);
    $updateQuery2 = "UPDATE campaign_info SET click_test = '$clk3'  where id = $id";
    $executeQuery = mysqli_query($connectDB, $updateQuery2);
    header("location:clicktest.php?id=" . $id);

    ob_end_flush();
  };
};

?>
<?php
if ($cclk == $sclk) {
?><div class="popup" style="">
    <h3>Are You Satisfied With Your Landing Page?</h3>
    <button name="yes" class="btn1">Yes</button><button name="no" class="btn2">No</button>
  </div><?php
        if (isset($_POST['yes'])) {
        ?> <div class="popup2" style="">
      <h3 Style="font-size:30px;">congratulation</h3>
      <h6 Style="font-size:20px;">Your Creative Is Ready</h6>
      <a target="_blank" href="https://publisherplex.io/selfserve/adtags.php?id=<?php echo $id?>" class="btn btn-success">View Adtag Page</a>
      <h6 Style="width: 250px;font-size: 15px;top: 20px;position: relative;margin: 0 auto;">Enter Email-id the Creative Will be Sent to :-</h6><br><br>
      <form method="POST"><input name="emailadd" type="text" required>
      <button class="btn btn-primary" name='adtagbtn'>Mail to</button></form>
    </div><?php
        } else if (isset($_POST['no'])) {
          for ($p = 0; $p < count($str_arr); $p++) {
            $clk2[$p] = 0;
          };
          $clk3 = implode(",", $clk2);
          $updateQuery2 = "UPDATE campaign_info SET click_test = '$clk3'  where id = $id";
          $executeQuery = mysqli_query($connectDB, $updateQuery2);
          header("location:clicktest.php?id=" . $id);

          ob_end_flush();
        };
      }
          ?>
</div>

<?php

if (isset($_POST['adtagbtn'])) {
    $email=$_POST['emailadd'];
    ?> <div class="popup" >
      <h3 Style="font-size:30px;">Mail Send </h3>
      <h6 Style="font-size:20px;">Want to create new ad ?</h6>
      <a href="./update_creative.php" style="margin-right:20px;font-size:18px;margin-top:20px;" class="btn btn-success">Yes</a><a href="./logout.php" style="margin-left:20px;font-size:18px;margin-top:20px;" class="btn btn-danger">No</a>
    </div><?php
    
  $to = "$email";
    $message = "Hello Team, <br> \r\n\r\n";

    $message .="PFB adtags and previews for " .  $cmp_tl . "<br><br> \r\n\r\n";
    
    $message .="Adtag - https://publisherplex.io/selfserve/adtags.php?id=".$id."<br><br> \r\n\r\n";
    
    $message .="Preview - https://publisherplex.io/selfserve/previews.php?id=".$id."<br><br> \r\n\r\n";
    
    $message .="Thanks and Regargs <br>\r\n";
    $message .="Team Hockeycurve";
     $subject ="Testing -" . $cmp_tl;
    $header = "From:jasmeet.singh@hockeycurve.com \r\n";
    $header .= "MIME-Version: 1.0\r\n";
                 $header .= "Content-type: text/html\r\n";

                     
                     $retval = mail ($to,$subject,$message,$header);
                    //  echo $header;
                     if( $retval == true ) {
                        echo "Email was send successfully please close the window";
                        exit;
                     }else {
                        echo "Message could not be sent...";
                     }
                     
    header("location:https://publisherplex.io/selfserve/adtags.php?id=".$id);
}

if (isset($_POST['retest'])) {
  for ($p = 0; $p < count($str_arr); $p++) {
    $clk2[$p] = 0;
  };
  $clk3 = implode(",", $clk2);
  $updateQuery2 = "UPDATE campaign_info SET click_test = '$clk3'  where id = $id";
  $executeQuery = mysqli_query($connectDB, $updateQuery2);
  header("location:clicktest.php?id=" . $id);

  ob_end_flush();
};
?>

<script>
document.getElementById("updt_creat").addEventListener("click",()=>{
        window.location = "./update_creative.php";
    })
document.getElementById("cam_inf").addEventListener("click",()=>{
        window.location = "./index.php";
    })
    document.getElementById("temp").addEventListener("click",()=>{
        window.location = "./template/index.php?id=<?php echo $id; ?>";
    })
    document.getElementById("upld_ast").addEventListener("click",()=>{
        window.location = "./uploadasset/creative.php?id=<?php echo $id; ?>";
    })
    document.getElementById("update_anim").addEventListener("click",()=>{
        window.location = "./update/update.php?id=<?php echo $id; ?>";
    })
    <?php
         if($adtag_type!="dcm"){
             ?>
                 document.getElementById("add_trk").addEventListener("click",()=>{
                 window.location = "trackers.php?id=<?php echo $id; ?>";
                 })
             <?php
         }
    ?>
   
  
  var lstr = <?php echo count($str_arr) ?>;
  focus();
  const listener = addEventListener('blur', function() {
    iframe = document.activeElement.id;
    var click = iframe.split("-");
    if (document.activeElement.id === iframe) {
      setTimeout(function clk() {
        document.getElementById(click[2]).click();
        console.log(click[2]);
      }, 200);

    }
    removeEventListener('blur', listener);
  });
</script>

</body>

</html>