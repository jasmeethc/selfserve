<?php
ob_start();
session_start();
    if(!$_SESSION['email']){
      header("location: ./login.php");
    }
include "conn.php";
error_reporting(E_ERROR | E_PARSE);
$id = $_GET['id'];
if (isset($_POST['id'])) {
  $id = $_GET['id'];
}

?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
  <title>Previews</title>
  <link rel="stylesheet" href="style.css" />
  <style>
    .container {
      margin-left: 100px;
    }

    .popup {
      height: 200px;
      width: 300px;
      position: fixed;
      top: 45%;
      left: 42%;
      color: black;
      font-weight: bold;
      border: 3px solid black;
      background: #b9ebff;
      text-align: center;
      justify-content: center;
    }

    .popup2 {
      height: 200px;
      width: 300px;
      position: fixed;
      top: 45%;
      left: 42%;
      border: 3px solid black;
      z-index: 10;
      background: #b9ebff;
      text-align: center;
      justify-content: center;
    }

    .btn1 {
      position: absolute;
      top: 68%;
      left: 10%;
      background-color: green;
      color: white;
      width: 110px;
      height: 33px
    }

    .btn2 {
      position: absolute;
      top: 68%;
      background-color: red;
      color: white;
      width: 110px;
      height: 33px
    }

    .btn3 {
      position: absolute;
      top: 50%;
      left: 26%;
      background-color: green;
      color: white;
      width: 140px;
      height: 33px
    }

    .box1 {
      position: absolute;
      top: 75px;
      left: 115px;
      border: 2px solid grey;
      width: 1447px;
      height: 40px;
      display: flex;
      align-items: center;
    }
  </style>
</head>

<body>
    <ul class="list-unstyled multi-steps">
    <li style="cursor:pointer;" id="updt_creat">Update Creative</li>
    <li style="cursor:pointer;" id="cam_inf">Campaign information</li>
    <li style="cursor:pointer;" id="temp">select template</li>
    <li style="cursor:pointer;" id="upld_ast">Upload assets</li>
    <li style="cursor:pointer;" id="update_anim">Update animation</li>
    <?php 
        $sql2="SELECT * FROM `campaign_info` WHERE id='$id'";
        $data2=mysqli_query($connectDB,$sql2);
        if(mysqli_num_rows($data2)>0){
    while($row2=mysqli_fetch_assoc($data2)){
        $adtag_type=$row2['adtag_type'];
            if($adtag_type!="dcm"){
                ?>
                <li class="is-active">Add Tracker</li>
                <?php
            }
    }}
    ?>
    
    <li>Click Test</li>
    <li>Previews/Adtags</li>
  </ul>
  <a href="./logout.php" style="position:absolute;top:5px;right:5px;color: #fff;background-color: #d9534f;border-color: #d43f3a;text-decoration: none;padding: 7px;border-radius: 5px">Logout</a>
  <?php 
  $sql = "SELECT * FROM `campaign_info` WHERE id=$id LIMIT 1";
      $result = mysqli_query($connectDB, $sql);
      $row = mysqli_fetch_assoc($result);
  if($row["adtag_type"] != "dcm"){ ?>
  <div style="display:flex;justify-content: center;"><button style="position: absolute;top:185px;" onclick="same()">Same for all</button></div>
  <?php } ?>

  <form method="POST">
    <div>
      <h2 style="text-align:center"><?php echo $row['campaign_title'] ?></h2>
      <h4 style="text-align:center">Adtag Type - <?php echo $row['adtag_type'] ?></h4>
      <?php 
      $camp = $row['campaign_name'];
      $dims = $row['dimension'];

      $str_arr = explode(",", $dims);
        
      ?>
      <?php
    
    // $i = 0;
    //       while ($i < count($str_arr)) {

    //  $i++;}
      ?>

      

      <br><br>
      
      <button name="create" style="position: absolute;top: 140px;right: 235px;">Create Ad</button>
    </div>
    <br>
    <div class="container">
      
          <?php
          
          $i = 0;
          while ($i < count($str_arr)) {
            $wh_dim = explode("x", $str_arr[$i]) ?>
            <div style="display: flex;">
              <div style="margin: 0px 20px;font-size:18px;"><?php echo $str_arr[$i] ?></div><br>
              <div style="margin: 0px 20px;" id='<?php echo $i ?>'>
              <div id='main-ad-tag<?php echo $i ?>' style="width:<?php echo $wh_dim[0] ?>px;height:<?php echo $wh_dim[1] ?>px;position:relative;"><?php
                $sql2 = "SELECT * FROM `creativecode` WHERE `campaign` = '$camp' AND `dimension` = '$str_arr[$i]'";
                $result2 = mysqli_query($connectDB, $sql2);
                $row2 = mysqli_fetch_assoc($result2);
                echo $row2['finalcode'];
                ?></div><br>
                
              </div>
              <div style="margin: 0px 100px;font-size:18px;" class="addtck">
  <?php 
    if ($row["adtag_type"] == "dv360") { 
        if($row["lp_type"]=="lp"){
            ?>
    <span>Add Landing URL & UTM</span><br><input name="land<?php echo $i ?>" id="lntk<?php echo $i ?>" type="text" placeholder="Add Landing page" value="" required><br>
     
    <?php
        } else if($row["lp_type"]=="utm"){
            ?>
    <span>Add Landing URL & UTM</span><br><input name="land<?php echo $i ?>" id="lntk<?php echo $i ?>" type="text" placeholder="Add Landing URL & UTM" value="" required><br>
     
    <?php
        } else if($row["lp_type"]=="imp"){ ?> 
 <span>Add Impression Tracker</span><br><input name="impp<?php echo $i ?>" id="imtk<?php echo $i ?>" type="text" placeholder="Add Impression Tracker" value="" required><br><br>
 <span>Add Click Tracker</span><br><input name="clik<?php echo $i ?>" id="cltk<?php echo $i ?>" type="text" placeholder="Add Click Tracker" value="" required><br>

<?php }

     } ?>
  </div>
  </form>
  <?php
  if ($row["adtag_type"] == "dv360") {
    if($row["lp_type"]=="imp"){
   $sql5 = "SELECT * FROM `creativecode` WHERE `campaign` = '$camp' AND `dimension` = '$str_arr[$i]'";
                $result5 = mysqli_query($connectDB, $sql5);
                $row5 = mysqli_fetch_assoc($result5);
                $blue =  $row5['impressions']; 
                
                $sql6 = "SELECT * FROM `creativecode` WHERE `campaign` = '$camp' AND `dimension` = '$str_arr[$i]'";
                $result6 = mysqli_query($connectDB, $sql6);
                $row6 = mysqli_fetch_assoc($result6);
                $blue2 =  $row6['clicks']; 
                ?> 
                <script>
                    var asa = "<?php echo $blue ?>";
                document.getElementById('imtk<?php echo $i ?>').value = asa;
                var asa2 = "<?php echo $blue2 ?>";
                document.getElementById('cltk<?php echo $i ?>').value = asa2;
                </script>
                <?php
                }
      else if ($row["lp_type"]=="utm"||$row["lp_type"]=="lp") {
                    $sql6 = "SELECT * FROM `creativecode` WHERE `campaign` = '$camp' AND `dimension` = '$str_arr[$i]'";
                $result6 = mysqli_query($connectDB, $sql6);
                $row6 = mysqli_fetch_assoc($result6);
                $blue2 =  $row6['clicks']; 
                ?> 
                <script>
                var asa2 = "<?php echo $blue2 ?>";
                document.getElementById('lntk<?php echo $i ?>').value = asa2;
                </script>
                <?php
                }
  } 
                ?>
    
  
</div><br><br><br><?php
            $i++;
          }
        ?>



<?php
    $data_arr = array();
if(isset($_POST['create'])){
    
for($ij=0;$ij<count($str_arr);$ij++){
    
    for ($p = 0; $p < count($str_arr); $p++){
        
        if ($row["lp_type"] == "imp") {
        $impressions = $_POST['impp'.$p];
        $clicks = $_POST['clik'.$p];
        $sql3 = "UPDATE creativecode SET clicks = '$clicks'  WHERE `campaign` = '$camp' AND `dimension` = '$str_arr[$p]'";
        $executeQuery = mysqli_query($connectDB, $sql3);
        $sql4 = "UPDATE creativecode SET impressions = '$impressions'  WHERE `campaign` = '$camp' AND `dimension` = '$str_arr[$p]'";
        $executeQuery2 = mysqli_query($connectDB, $sql4);
        header("location:trackers.php?id=" . $id);
        } else if ($row["lp_type"] == "utm" || $row["lp_type"] == "lp") {
            $clicks = $_POST['land'.$p];
            $sql7 = "UPDATE creativecode SET clicks = '$clicks'  WHERE `campaign` = '$camp' AND `dimension` = '$str_arr[$p]'";
        $executeQuery3 = mysqli_query($connectDB, $sql7);
        header("location:trackers.php?id=" . $id);

        }
        
    };
    
    $url = 'https://dynamique.hockeycurve.com/publish-creativedata?key=Kth7NS3ACWX2';
    $sql_arr = "SELECT * FROM `creativecode` WHERE `campaign` = '$camp' AND `dimension` = '$str_arr[$ij]'";
        $result_arr = mysqli_query($connectDB, $sql_arr);
        $row_arr = mysqli_fetch_assoc($result_arr);
        $client_dt = $row_arr['client'];
        $fcat_dt = $row_arr['filter'];
        $dim_dt = $row_arr['dimension'];
        if($row_arr['clicks']!=""&&$row_arr['impressions']!=""){
            $impressiontracker='<script>
imp1="'.$row_arr["impressions"].'".split("[timestamp]")[0]
imp2="'.$row_arr["impressions"].'".split("[timestamp]")[1]

var time = (new Date())/1000
    var frame = document.getElementById("imptag");
    function trigIframe(){
        var frame = document.createElement("iframe")
        frame.style["display"] = "none"
        frame.src = imp1+time+imp2
        document.body.appendChild(frame)
    }
    setTimeout(trigIframe, 5000)
    </script>
';
            $clicktracker='<script>

document.getElementById("clickurl").href = "'.$row_arr['clicks'].'";var elem = document.getElementsByTagName("a")[0];if(json["click_macro"]){elem.href = elem.href;var target = json["click_macro"];var url = elem.href;elem.href = "https://ad.hockeycurve.com/clk.php?redirect="+url+"&tracking="+encodeURIComponent(target)+"&stats="+encodeURIComponent(json[`stats`])+"&token_id="+encodeURIComponent(json[`token_id`])}
</script>';
        $content_dt = $row_arr['finalcode'].$impressiontracker.$clicktracker;
        }
        else if($row_arr['clicks']!=""){
            $clicktracker='<script>

document.getElementById("clickurl").href = "'.$row_arr['clicks'].'";var elem = document.getElementsByTagName("a")[0];if(json["click_macro"]){elem.href = elem.href;var target = json["click_macro"];var url = elem.href;elem.href = "https://ad.hockeycurve.com/clk.php?redirect="+url+"&tracking="+encodeURIComponent(target)+"&stats="+encodeURIComponent(json[`stats`])+"&token_id="+encodeURIComponent(json[`token_id`])}
</script>';
        $content_dt = $row_arr['finalcode'].$clicktracker;
        }
        else{
            $clicktracker='<script>
                var landing_page = "https://www.primevideo.com/";if(window.location.href.indexOf("lp0")!=-1){landing_page = window.location.href.split("lp0=")[1].split("&")[0];}
    
    var elem = document.getElementsByTagName("a")[0];
    if(json[`click_macro`]){
        elem.href = elem.href
        var target = json[`click_macro`];
        var url = landing_page;
        elem.href = "https://ad.hockeycurve.com/clk.php?redirect="+encodeURIComponent(url)+"&tracking="+encodeURIComponent(target)+"&stats="+encodeURIComponent(json[`stats`])+"&token_id="+encodeURIComponent(json[`token_id`]);}
            </script>';
            $content_dt = $row_arr['finalcode'].$clicktracker;
        }
        
        $data_arr[$dim_dt] = $content_dt;
    }
        
    $postData = array(
        'client' => $client_dt,
        'category' => $fcat_dt,
        'concept' => 'popular',
        'data' => $data_arr
    );
    
    $abc = json_encode($postData);
    // Setup cURL
    $ch = curl_init($url);
    curl_setopt_array($ch, array(
        CURLOPT_POST => TRUE,
        CURLOPT_RETURNTRANSFER => TRUE,
        CURLOPT_HTTPHEADER => array(
            'Content-Type: application/json'
        ),
        CURLOPT_POSTFIELDS => $abc
    ));

// Send the request
$response = curl_exec($ch);
header("location:clicktest.php?id=" . $id);
}

if ($row["lp_type"] == "imp"){?>
    <script>
        var lstr = <?php echo count($str_arr) ?>;
         function same(){

var imval = document.getElementById('imtk0').value;
var clval = document.getElementById('cltk0').value;

for (var p = 0; p < lstr; p++) {
    document.getElementById('imtk'+p).value = imval;
    document.getElementById('cltk'+p).value = clval;
    
}
}
    </script><?php
} else if ($row["lp_type"] == "utm" || $row["lp_type"] == "lp") {?>
<script>
    var lstr = <?php echo count($str_arr) ?>;
         function same(){
var lnval = document.getElementById('lntk0').value;
for (var p = 0; p < lstr; p++) {
    document.getElementById('lntk'+p).value = lnval;
}
}
</script><?php

}
?>

</div>

<script>
document.getElementById("updt_creat").addEventListener("click",()=>{
        window.location = "./update_creative.php";
    })
    document.getElementById("cam_inf").addEventListener("click",()=>{
        window.location = "./index.php";
    })
    document.getElementById("temp").addEventListener("click",()=>{
        window.location = "./template/index.php?id=<?php echo $id; ?>";
    })
    document.getElementById("upld_ast").addEventListener("click",()=>{
        window.location = "./uploadasset/creative.php?id=<?php echo $id; ?>";
    })
    document.getElementById("update_anim").addEventListener("click",()=>{
        window.location = "./update/update.php?id=<?php echo $id; ?>";
    })
</script>
</body>

</html>